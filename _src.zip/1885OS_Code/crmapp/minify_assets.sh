#!/bin/bash
./yii asset assets/compression/config.php config/assets_compressed.php