<?php
/**
 * Created by PhpStorm.
 * User: Hijarian
 * Date: 26.07.14
 * Time: 12:58
 */

namespace app\assets;
use yii\web\AssetBundle;
class AllAsset extends AssetBundle { }
