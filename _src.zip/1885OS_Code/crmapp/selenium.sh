#!/bin/bash
xvfb-run java -jar vendor/netwing/selenium-server-standalone/selenium-server-standalone-2.39.0.jar