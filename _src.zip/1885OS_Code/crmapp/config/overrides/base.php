<?php
return [
    'basePath' => realpath(__DIR__ . '/../../'),
    'components' => [
        'db' => [
            'class' => '\yii\db\Connection'
        ],
    ]
];

