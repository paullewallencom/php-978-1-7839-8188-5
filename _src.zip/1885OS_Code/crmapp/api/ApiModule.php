<?php
/**
 * Created by PhpStorm.
 * User: Hijarian
 * Date: 21.07.14
 * Time: 10:09
 */

namespace app\api;

use \yii\base\Module;

class ApiModule extends Module {  }
